import torch
from torch import nn, Tensor
from typing import Iterable, Dict
from ..SentenceTransformer import SentenceTransformer
from .. import util

from transformers import AutoModel
from sklearn.metrics.pairwise import paired_cosine_distances
class FlatNCEloss(nn.Module):
    """
        This loss expects as input a batch consisting of sentence pairs (a_1, p_1), (a_2, p_2)..., (a_n, p_n)
        where we assume that (a_i, p_i) are a positive pair and (a_i, p_j) for i!=j a negative pair.

        For each a_i, it uses all other p_j as negative samples, i.e., for a_i, we have 1 positive example (p_i) and
        n-1 negative examples (p_j). It then minimizes the negative log-likehood for softmax normalized scores.

        This loss function works great to train embeddings for retrieval setups where you have positive pairs (e.g. (query, relevant_doc))
        as it will sample in each batch n-1 negative docs randomly.

        The performance usually increases with increasing batch sizes.

        For more information, see: https://arxiv.org/pdf/1705.00652.pdf
        (Efficient Natural Language Response Suggestion for Smart Reply, Section 4.4)

        You can also provide one or multiple hard negatives per anchor-positive pair by structering the data like this:
        (a_1, p_1, n_1), (a_2, p_2, n_2)

        Here, n_1 is a hard negative for (a_1, p_1). The loss will use for the pair (a_i, p_i) all p_j (j!=i) and all n_j as negatives.

        Example::

            from sentence_transformers import SentenceTransformer,  SentencesDataset, LoggingHandler, losses
            from sentence_transformers.readers import InputExample

            model = SentenceTransformer('distilbert-base-nli-mean-tokens')
            train_examples = [InputExample(texts=['Anchor 1', 'Positive 1']),
                InputExample(texts=['Anchor 2', 'Positive 2'])]
            train_dataset = SentencesDataset(train_examples, model)
            train_dataloader = DataLoader(train_dataset, shuffle=True, batch_size=train_batch_size)
            train_loss = losses.MultipleNegativesRankingLoss(model=model)
    """
    def __init__(self, model: SentenceTransformer, scale: float = 20.0, similarity_fct = util.cos_sim):
        """
        :param model: SentenceTransformer model
        :param scale: Output of similarity function is multiplied by scale value
        :param similarity_fct: similarity function between sentence embeddings. By default, cos_sim. Can also be set to dot product (and then set scale to 1)
        """
        super(FlatNCEloss, self).__init__()
        self.model = model
        #self.model2 = model
        self.yuemodel = AutoModel.from_pretrained("bert-base-multilingual-uncased")
        self.scale = scale
        self.similarity_fct = similarity_fct
        self.K = 512
        self.register_buffer("queue1", torch.randn(self.K, 768))
        self.register_buffer("queue2", torch.randn(self.K, 768))
        self.queue1 = nn.functional.normalize(self.queue1, dim=1)
        self.queue2 = nn.functional.normalize(self.queue2, dim=1)
        self.register_buffer("queue_ptr", torch.zeros(1, dtype=torch.long))
        #self.cross_entropy_loss = nn.CrossEntropyLoss()
        #self.mseloss = nn.MSELoss(reduction='mean')
        """
        self.pinyin_embeddings = PinyinEmbedding(
            pinyin_map_len=32,  # 32
            embedding_size=128,
            pinyin_out_dim=768,  # 768
        )
        self.tokenizer = ChineseBertTokenizerFast.from_pretrained("junnyu/ChineseBERT-base")
        """

    def _dequeue_and_enqueue1(self, keys):
        # gather keys before updating queue
        #keys = concat_all_gather(keys)

        batch_size = keys.shape[0]

        #ptr = int(self.queue_ptr)
        assert self.K % batch_size == 0  # for simplicity

        # replace the keys at ptr (dequeue and enqueue)
        #self.queue[:, ptr:ptr + batch_size] = keys
        self.queue1 = self.queue1[batch_size:]
        self.queue1 = torch.cat((self.queue1,keys),dim=0)
        #ptr = (ptr + batch_size) % self.K  # move pointer

        #self.queue_ptr[0] = ptr
    def _dequeue_and_enqueue2(self, keys):
        # gather keys before updating queue
        #keys = concat_all_gather(keys)

        batch_size = keys.shape[0]

        #ptr = int(self.queue_ptr)
        assert self.K % batch_size == 0  # for simplicity

        # replace the keys at ptr (dequeue and enqueue)
        #self.queue[:, ptr:ptr + batch_size] = keys
        self.queue2 = self.queue2[batch_size:]
        self.queue2 = torch.cat((self.queue2,keys),dim=0)
        #ptr = (ptr + batch_size) % self.K  # move pointer

        #self.queue_ptr[0] = ptr


    def forward(self, sentence_features: Iterable[Dict[str, Tensor]], labels: Tensor):
        sentence_feature_a, sentence_feature_b ,sentence_feature_c= sentence_features
        #self.model[0].auto_model.set_flag("data_aug_pinyin", True)
        #self.model[0].auto_model.unset_flag("data_aug_pinyin")
        #self.model[0].auto_model.set_flag("adapter", True)
        #self.model[0].auto_model.unset_flag("adapter")
        #assert type(sentence_feature_b)=='tensor',print(sentence_feature_b)

        padding = torch.nn.ZeroPad2d(
            padding=(0, sentence_feature_a['input_ids'].shape[1] - sentence_feature_c['input_ids'].shape[1], 0, 0))
        sentence_feature_c['input_ids'] = padding(sentence_feature_c['input_ids'])
        yue_embedding = self.yuemodel.embeddings(sentence_feature_c['input_ids'])

        rep_a = self.model(sentence_feature_a)['sentence_embedding']
        rep_c = self.model(sentence_feature_a)['sentence_embedding']
        """
        #self.model[0].auto_model.set_flag("adapter", True)
        self.model[0].auto_model.set_flag("data_aug_yue.embedding", yue_embedding)
        self.model[0].auto_model.set_flag("data_aug_yue", True)
        self.model[0].auto_model.set_flag("simi", 0.8)
        rep_b = self.model(sentence_feature_a)['sentence_embedding']
        self.model[0].auto_model.unset_flag("simi")
        self.model[0].auto_model.unset_flag("data_aug_yue")
        self.model[0].auto_model.unset_flag("data_aug_yue.embedding")
        #self.model[0].auto_model.unset_flag("adapter")
        """



        scores_pos1 = self.similarity_fct(rep_a,rep_c)* self.scale
        scores_neg1 = self.similarity_fct(rep_a,self.queue1.clone().detach())* self.scale
        scores1 = torch.cat((scores_pos1, scores_neg1), 1)
        print(scores_pos1)
        """
        scores_pos2 = self.similarity_fct(rep_a, rep_b) * self.scale
        scores_neg2 = self.similarity_fct(rep_b, self.queue2.clone().detach()) * self.scale
        scores2 = torch.cat((scores_pos2, scores_neg2), 1)
        print(scores_pos2)
        """
        #labels1= torch.zeros(scores1.shape[0], dtype=torch.long).cuda()
        #scores_positive2 = (1-paired_cosine_distances(rep_a,rep_b) )* self.scale
        #scores = torch.cat((scores1,scores2),1)
        #score = scores.clone().detach().requires_grad_(True)
        #score2 = scores2.clone().detach().requires_grad_(True)
        # score = scores.clone()
        # score2 = scores2.clone()


        labels1 = torch.tensor(range(len(scores1)), dtype=torch.long, device=scores1.device)  # Example a[i] should match with b[i]
        #labels2 = torch.tensor(range(len(scores2)), dtype=torch.long, device=scores.device)
        one_hot1 = torch.nn.functional.one_hot(labels1,num_classes=scores1.shape[1]).float()
        one_hot2 = torch.nn.functional.one_hot(labels1).float()# 对标签进行one_hot编码
        one_hot3 = torch.ones_like(one_hot1).float()-one_hot1
        #one_hot2 = F.one_hot(labels2).float()
        #one_hot = torch.cat((one_hot1, one_hot2), 1)
        """
        softmax1 = torch.exp(scores1) / torch.sum(torch.exp(scores1), dim=1).reshape(-1, 1)
        logsoftmax1 = torch.log(softmax1)
        loss1 = -torch.sum(one_hot1 * logsoftmax1) / labels1.shape[0]

        softmax2 = torch.exp(scores2) / torch.sum(torch.exp(scores2), dim=1).reshape(-1, 1)
        logsoftmax2 = torch.log(softmax2)
        loss2 = -torch.sum(one_hot1 * logsoftmax2) / labels1.shape[0]
        """
        ##flatNCE loss
        neg = torch.sum(one_hot3*torch.exp(scores1), dim=1).reshape(-1, 1)
        pos = torch.sum(one_hot1*torch.exp(scores1), dim=1).reshape(-1, 1)
        loss3 = torch.sum(torch.log(neg)-pos)/ labels1.shape[0]



        #return 0.6*self.cross_entropy_loss(scores, labels) + 0.4*self.cross_entropy_loss(scores2, labels2)
        #return self.cross_entropy_loss(scores, label)
        self._dequeue_and_enqueue1(rep_c)
        #self._dequeue_and_enqueue2(rep_b)
        #print(loss1,loss2)
        #loss = loss1 + loss2/(loss1/loss2).detach()
        #print(loss1)
        #print(loss2)
        print(loss3)
        return loss3
        """
        reps = [self.model(sentence_feature)['sentence_embedding'] for sentence_feature in sentence_features]
        embeddings_a = reps[0]
        embeddings_b = torch.cat(reps[1:])

        scores = self.similarity_fct(embeddings_a, embeddings_b) * self.scale
        labels = torch.tensor(range(len(scores)), dtype=torch.long, device=scores.device)  # Example a[i] should match with b[i]
        return self.cross_entropy_loss(scores, labels)
        """

        """
        sentence_feature_a, sentence_feature_b = sentence_features

        ori_feature_keys = set(sentence_feature_a.keys())  # record the keys since the features will be updated

        sentence_feature_a = {k: v for k, v in sentence_feature_a.items() if k in ori_feature_keys}
        sentence_feature_b = {k: v for k, v in sentence_feature_b.items() if k in ori_feature_keys}
        input_ids_a = sentence_feature_a['input_ids']

        input_shape_a = input_ids_a.size()
        seq_length_a = input_shape_a[1]

        ##生成pinyin_ids_a
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        tokens_a = self.tokenizer.convert_ids_to_tokens(input_ids_a[0])
        text_a = "".join(tokens_a).replace("[CLS]", "").replace("[SEP]", "").replace("[PAD]", "").strip()
        inputs_a = self.tokenizer(text_a, return_tensors="pt").to(device)
        pinyin_ids_a = inputs_a['pinyin_ids'][0].reshape(inputs_a['input_ids'].size()[0],
                                                         inputs_a['input_ids'].size()[1], -1).to(device)
        pad_a = nn.ZeroPad2d(padding=(0, 0, 0, seq_length_a - inputs_a['input_ids'].size()[1]))
        pinyin_ids_a = pad_a(pinyin_ids_a)
        ##pinyin_embedding_a
        pinyin_embeddings_a = self.pinyin_embeddings(pinyin_ids_a).to(device)

        rep_b = self.model(sentence_feature_b)['sentence_embedding']
        self.model[0].auto_model.set_flag("data_aug_pinyin", True)
        self.model[0].auto_model.set_flag("pinyin_embedding", pinyin_embeddings_a)
        adv_rep_a = self.model(sentence_feature_a)['sentence_embedding']
        scores = self.similarity_fct(adv_rep_a, rep_b) * self.scale
        labels = torch.tensor(range(len(scores)), dtype=torch.long,device=scores.device)  # Example a[i] should match with b[i]
        return self.cross_entropy_loss(scores, labels)
        """


    def get_config_dict(self):
        return {'scale': self.scale, 'similarity_fct': self.similarity_fct.__name__}

def concat_all_gather(tensor):
    """
    Performs all_gather operation on the provided tensors.
    *** Warning ***: torch.distributed.all_gather has no gradient.
    """
    tensors_gather = [torch.ones_like(tensor)
        for _ in range(torch.distributed.get_world_size())]
    torch.distributed.all_gather(tensors_gather, tensor, async_op=False)

    output = torch.cat(tensors_gather, dim=0)
    return output

