import torch
from torch import nn, Tensor
from typing import Union, Tuple, List, Iterable, Dict

from transformers import AutoModel
class MSELoss(nn.Module):
    """
    Computes the MSE loss between the computed sentence embedding and a target sentence embedding. This loss
    is used when extending sentence embeddings to new languages as described in our publication
    Making Monolingual Sentence Embeddings Multilingual using Knowledge Distillation: https://arxiv.org/abs/2004.09813

    For an example, see the documentation on extending language models to new languages.
    """
    def __init__(self, model):
        super(MSELoss, self).__init__()
        self.model = model
        self.loss_fct = nn.MSELoss(reduce="mean")
        self.yuemodel = AutoModel.from_pretrained("bert-base-multilingual-uncased")
    def forward(self, sentence_features: Iterable[Dict[str, Tensor]], labels: Tensor):
        sentence_feature_a, sentence_feature_b, sentence_feature_c= sentence_features
        # self.model[0].auto_model.set_flag("data_aug_pinyin", True)
        # self.model[0].auto_model.unset_flag("data_aug_pinyin")
        # self.model[0].auto_model.set_flag("adapter", True)
        # self.model[0].auto_model.unset_flag("adapter")
        # assert type(sentence_feature_b)=='tensor',print(sentence_feature_b)

        padding = torch.nn.ZeroPad2d(
            padding=(0, sentence_feature_a['input_ids'].shape[1] - sentence_feature_c['input_ids'].shape[1], 0, 0))
        sentence_feature_c['input_ids'] = padding(sentence_feature_c['input_ids'])
        sentence_feature_c['attention_mask'] = padding(sentence_feature_c['attention_mask'])
        sentence_feature_c['token_type_ids'] = padding(sentence_feature_c['token_type_ids'])
        assert sentence_feature_b['input_ids'].shape == sentence_feature_a['input_ids'].shape
        with torch.no_grad():
            yue_embedding = self.yuemodel.embeddings(sentence_feature_c['input_ids'],
                                                     sentence_feature_c['token_type_ids'],
                                                     sentence_feature_c['attention_mask'])

        rep_a = self.model(sentence_feature_a)['sentence_embedding']


        #self.model[0].auto_model.set_flag("adapter", True)
        self.model[0].auto_model.set_flag("data_aug_yue.embedding", yue_embedding)
        self.model[0].auto_model.set_flag("adapter", True)

        rep_b = self.model(sentence_feature_a)['sentence_embedding']

        self.model[0].auto_model.unset_flag("adapter")
        self.model[0].auto_model.unset_flag("data_aug_yue.embedding")
        #self.model[0].auto_model.unset_flag("adapter")

        return self.loss_fct(rep_a, rep_b)
