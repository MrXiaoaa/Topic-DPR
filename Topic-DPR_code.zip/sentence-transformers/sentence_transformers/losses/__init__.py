from .CosineSimilarityLoss import *
from .SoftmaxLoss import *
from .MultipleNegativesRankingLoss import *
from .MultipleNegativesRankingLossSup import *
from .TripletLoss import *
from .MSELoss import *
from .ContrastiveLoss import *
from .ContrastiveTensionLoss import *
from .OnlineContrastiveLoss import *
from .MegaBatchMarginLoss import *
from .DenoisingAutoEncoderLoss import *
from .MultipleCELoss import *
from .MixedCELoss import *
from .MultipleCE import *
from .PrefixContrastiveLoss import *
from .MulPrefixContrastiveLoss import *
from .mulprefix import *

#
# Triplet losses
from .BatchHardTripletLoss import *
from .BatchHardSoftMarginTripletLoss import *
from .BatchSemiHardTripletLoss import *
from .BatchAllTripletLoss import *
