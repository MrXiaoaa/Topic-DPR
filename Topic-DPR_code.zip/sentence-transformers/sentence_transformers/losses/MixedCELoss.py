import torch
from torch import nn, Tensor
from typing import Iterable, Dict
import torch.nn.functional as F
from ..SentenceTransformer import SentenceTransformer
from .. import util
# from chinesebert.tokenization_chinesebert_fast import ChineseBertTokenizerFast
# from chinesebert.pinyin_embedding import PinyinEmbedding
from transformers import AutoModel
import numpy


class MixedCELoss(nn.Module):
    """
        This loss expects as input a batch consisting of sentence pairs (a_1, p_1), (a_2, p_2)..., (a_n, p_n)
        where we assume that (a_i, p_i) are a positive pair and (a_i, p_j) for i!=j a negative pair.

        For each a_i, it uses all other p_j as negative samples, i.e., for a_i, we have 1 positive example (p_i) and
        n-1 negative examples (p_j). It then minimizes the negative log-likehood for softmax normalized scores.

        This loss function works great to train embeddings for retrieval setups where you have positive pairs (e.g. (query, relevant_doc))
        as it will sample in each batch n-1 negative docs randomly.

        The performance usually increases with increasing batch sizes.

        For more information, see: https://arxiv.org/pdf/1705.00652.pdf
        (Efficient Natural Language Response Suggestion for Smart Reply, Section 4.4)

        You can also provide one or multiple hard negatives per anchor-positive pair by structering the data like this:
        (a_1, p_1, n_1), (a_2, p_2, n_2)

        Here, n_1 is a hard negative for (a_1, p_1). The loss will use for the pair (a_i, p_i) all p_j (j!=i) and all n_j as negatives.

        Example::

            from sentence_transformers import SentenceTransformer,  SentencesDataset, LoggingHandler, losses
            from sentence_transformers.readers import InputExample

            model = SentenceTransformer('distilbert-base-nli-mean-tokens')
            train_examples = [InputExample(texts=['Anchor 1', 'Positive 1']),
                InputExample(texts=['Anchor 2', 'Positive 2'])]
            train_dataset = SentencesDataset(train_examples, model)
            train_dataloader = DataLoader(train_dataset, shuffle=True, batch_size=train_batch_size)
            train_loss = losses.MultipleNegativesRankingLoss(model=model)
    """

    def __init__(self, model: SentenceTransformer, scale: float = 20.0, similarity_fct=util.cos_sim):
        """
        :param model: SentenceTransformer model
        :param scale: Output of similarity function is multiplied by scale value
        :param similarity_fct: similarity function between sentence embeddings. By default, cos_sim. Can also be set to dot product (and then set scale to 1)
        """
        super(MixedCELoss, self).__init__()
        self.model = model
        self.yuemodel = AutoModel.from_pretrained("bert-base-chinese")
        self.scale = scale
        self.similarity_fct = similarity_fct
        self.cross_entropy_loss = nn.CrossEntropyLoss()
        # self.mseloss = nn.MSELoss(reduction='mean')
        """
        self.pinyin_embeddings = PinyinEmbedding(
            pinyin_map_len=32,  # 32
            embedding_size=128,
            pinyin_out_dim=768,  # 768
        )
        self.tokenizer = ChineseBertTokenizerFast.from_pretrained("junnyu/ChineseBERT-base")
        """

    def forward(self, sentence_features: Iterable[Dict[str, Tensor]], labels: Tensor):
        sentence_feature_a, sentence_feature_b ,_= sentence_features
        # self.model[0].auto_model.set_flag("data_aug_pinyin", True)
        # self.model[0].auto_model.unset_flag("data_aug_pinyin")
        # self.model[0].auto_model.set_flag("adapter", True)
        # self.model[0].auto_model.unset_flag("adapter")

        padding = torch.nn.ZeroPad2d(padding=(0, sentence_feature_a['input_ids'].shape[1]-sentence_feature_b['input_ids'].shape[1], 0, 0))
        sentence_feature_b['input_ids'] = padding(sentence_feature_b['input_ids'])
        sentence_feature_b['attention_mask'] = padding(sentence_feature_b['attention_mask'])
        sentence_feature_b['token_type_ids'] = padding(sentence_feature_b['token_type_ids'])
        #assert sentence_feature_b['input_ids'].shape==sentence_feature_a['input_ids'].shape

        reverse_embedding = self.yuemodel.embeddings(sentence_feature_b['input_ids'])

        rep_a = self.model(sentence_feature_a)['sentence_embedding']
        rep_b = self.model(sentence_feature_a)['sentence_embedding']

        beta =1

        lam = torch.tensor(numpy.random.beta(beta, beta))
        self.model[0].auto_model.set_flag("mixed", reverse_embedding)
        self.model[0].auto_model.set_flag("lam",lam)
        rep_c = self.model(sentence_feature_a)['sentence_embedding']
        self.model[0].auto_model.unset_flag("mixed")
        self.model[0].auto_model.unset_flag("lam")


        scores1 = self.similarity_fct(rep_a, rep_b) * self.scale
        scores2 = self.similarity_fct(rep_a, rep_c) * self.scale
        #scores3 = self.similarity_fct(rep_b,torch.flip(rep_c,[0]))
        # score = scores.clone().detach().requires_grad_(True)
        # score2 = scores2.clone().detach().requires_grad_(True)
        # score = scores.clone()
        # score2 = scores2.clone()

        labels1 = torch.tensor(range(len(scores1)), dtype=torch.long,
                               device=scores1.device)  # Example a[i] should match with b[i]

        one_hot1 = F.one_hot(labels1).float()
        softmax1 = torch.exp(scores1) / torch.sum(torch.exp(scores1), dim=1).reshape(-1, 1)
        softmax2 = torch.exp(scores2) / torch.sum(torch.exp(scores2), dim=1).reshape(-1, 1)
        #softmax3 = torch.exp(scores3) / torch.sum(torch.exp(scores3), dim=1).reshape(-1, 1)
        logsoftmax1 = torch.log(softmax1)
        logsoftmax2 = torch.log(softmax2)
        #logsoftmax3 = torch.log(softmax3)

        loss1 = -torch.sum(one_hot1 * logsoftmax1) / labels1.shape[0]
        # loss2 = (0.8 - torch.sum(scores1 * one_hot1) / (labels1.shape[0] * self.scale)).abs()
        loss2 = -torch.sum(one_hot1 * logsoftmax2) / labels1.shape[0]
        #loss3 = -torch.sum(one_hot1 * logsoftmax3) / labels1.shape[0]
        #loss4 = (0.8 - torch.sum(scores2 * one_hot1) / (labels1.shape[0] * self.scale)).abs()
        # labels2 = torch.tensor(range(len(scores2)), dtype=torch.long, device=scores.device)
        # return 0.6*self.cross_entropy_loss(scores, labels) + 0.4*self.cross_entropy_loss(scores2, labels2)
        # return self.cross_entropy_loss(scores, labels)
        # loss = (self.cross_entropy_loss(scores, labels)-0.005).abs()+0.005
        # loss = loss1 + loss2 + loss3 +loss4
        print(loss1)
        print(loss2)
        print(scores1)
        print(scores2)
        return loss1 + lam*loss2
        """
        reps = [self.model(sentence_feature)['sentence_embedding'] for sentence_feature in sentence_features]
        embeddings_a = reps[0]
        embeddings_b = torch.cat(reps[1:])

        scores = self.similarity_fct(embeddings_a, embeddings_b) * self.scale
        labels = torch.tensor(range(len(scores)), dtype=torch.long, device=scores.device)  # Example a[i] should match with b[i]

        return self.cross_entropy_loss(scores, labels)
        """

        """
        sentence_feature_a, sentence_feature_b = sentence_features

        ori_feature_keys = set(sentence_feature_a.keys())  # record the keys since the features will be updated

        sentence_feature_a = {k: v for k, v in sentence_feature_a.items() if k in ori_feature_keys}
        sentence_feature_b = {k: v for k, v in sentence_feature_b.items() if k in ori_feature_keys}
        input_ids_a = sentence_feature_a['input_ids']

        input_shape_a = input_ids_a.size()
        seq_length_a = input_shape_a[1]

        ##生成pinyin_ids_a
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        tokens_a = self.tokenizer.convert_ids_to_tokens(input_ids_a[0])
        text_a = "".join(tokens_a).replace("[CLS]", "").replace("[SEP]", "").replace("[PAD]", "").strip()
        inputs_a = self.tokenizer(text_a, return_tensors="pt").to(device)
        pinyin_ids_a = inputs_a['pinyin_ids'][0].reshape(inputs_a['input_ids'].size()[0],
                                                         inputs_a['input_ids'].size()[1], -1).to(device)
        pad_a = nn.ZeroPad2d(padding=(0, 0, 0, seq_length_a - inputs_a['input_ids'].size()[1]))
        pinyin_ids_a = pad_a(pinyin_ids_a)
        ##pinyin_embedding_a
        pinyin_embeddings_a = self.pinyin_embeddings(pinyin_ids_a).to(device)

        rep_b = self.model(sentence_feature_b)['sentence_embedding']
        self.model[0].auto_model.set_flag("data_aug_pinyin", True)
        self.model[0].auto_model.set_flag("pinyin_embedding", pinyin_embeddings_a)
        adv_rep_a = self.model(sentence_feature_a)['sentence_embedding']
        scores = self.similarity_fct(adv_rep_a, rep_b) * self.scale
        labels = torch.tensor(range(len(scores)), dtype=torch.long,device=scores.device)  # Example a[i] should match with b[i]
        return self.cross_entropy_loss(scores, labels)
        """

    def get_config_dict(self):
        return {'scale': self.scale, 'similarity_fct': self.similarity_fct.__name__}





