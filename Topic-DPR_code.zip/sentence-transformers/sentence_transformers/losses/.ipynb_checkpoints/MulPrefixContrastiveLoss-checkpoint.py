import torch
from torch import nn, Tensor
from typing import Iterable, Dict
from ..SentenceTransformer import SentenceTransformer
from .. import util

from transformers import AutoModel, AutoTokenizer
from sklearn.metrics.pairwise import paired_cosine_distances


class MulPrefixContrastiveLoss(nn.Module):
    """
        This loss expects as input a batch consisting of sentence pairs (a_1, p_1), (a_2, p_2)..., (a_n, p_n)
        where we assume that (a_i, p_i) are a positive pair and (a_i, p_j) for i!=j a negative pair.

        For each a_i, it uses all other p_j as negative samples, i.e., for a_i, we have 1 positive example (p_i) and
        n-1 negative examples (p_j). It then minimizes the negative log-likehood for softmax normalized scores.

        This loss function works great to train embeddings for retrieval setups where you have positive pairs (e.g. (query, relevant_doc))
        as it will sample in each batch n-1 negative docs randomly.

        The performance usually increases with increasing batch sizes.

        For more information, see: https://arxiv.org/pdf/1705.00652.pdf
        (Efficient Natural Language Response Suggestion for Smart Reply, Section 4.4)

        You can also provide one or multiple hard negatives per anchor-positive pair by structering the data like this:
        (a_1, p_1, n_1), (a_2, p_2, n_2)

        Here, n_1 is a hard negative for (a_1, p_1). The loss will use for the pair (a_i, p_i) all p_j (j!=i) and all n_j as negatives.

        Example::

            from sentence_transformers import SentenceTransformer,  SentencesDataset, LoggingHandler, losses
            from sentence_transformers.readers import InputExample

            model = SentenceTransformer('distilbert-base-nli-mean-tokens')
            train_examples = [InputExample(texts=['Anchor 1', 'Positive 1']),
                InputExample(texts=['Anchor 2', 'Positive 2'])]
            train_dataset = SentencesDataset(train_examples, model)
            train_dataloader = DataLoader(train_dataset, shuffle=True, batch_size=train_batch_size)
            train_loss = losses.MultipleNegativesRankingLoss(model=model)
    """

    def __init__(self, model: SentenceTransformer, scale: float = 20.0, similarity_fct=util.cos_sim):
        """
        :param model: SentenceTransformer model
        :param scale: Output of similarity function is multiplied by scale value
        :param similarity_fct: similarity function between sentence embeddings. By default, cos_sim. Can also be set to dot product (and then set scale to 1)
        """
        super(MulPrefixContrastiveLoss, self).__init__()
        self.model = model

        # self.model2 = model
        self.scale1  = 0.1
        self.scale2 =  20.0
        self.similarity_fct = similarity_fct
        self.dot = util.dot_score
        self.K = 54  # 416
        self.m = 0.999
        self.mlm_probability = 0.15
        self.prompt_number= self.model[0].auto_model.prefix_tokens_number
        # self.register_buffer("queue", torch.randn(self.K, 768))
        # self.register_buffer("queue", torch.normal(mean=0, std=1, size= (self.K, 768)))
        self.register_buffer("queue", torch.randn(self.prompt_number-1,self.K, 768) )
        self.noise_lambda = 0.1
        self.tokenizer = AutoTokenizer.from_pretrained("bert-base-uncased")
        # self.queue2 = nn.functional.normalize(self.queue2, dim=1)
        # self.register_buffer("queue_ptr", torch.zeros(1, dtype=torch.long))
        # self.cross_entropy_loss = nn.CrossEntropyLoss()
        self.CrossEntropyLoss = nn.CrossEntropyLoss()
        self.margin = 0.5
        self.max = torch.nn.ReLU()
        self.mse = nn.MSELoss()
        self.prefix_tokens = self.model[0].auto_model.prefix_tokens

        """
        self.pinyin_embeddings = PinyinEmbedding(
            pinyin_map_len=32,  # 32
            embedding_size=128,
            pinyin_out_dim=768,  # 768
        )
        self.tokenizer = ChineseBertTokenizerFast.from_pretrained("junnyu/ChineseBERT-base")
        """

    def _dequeue_and_enqueue(self, keys,prefix_labels):
        # gather keys before updating queue
        # keys = concat_all_gather(keys)


        prefix_labels = torch.tensor(prefix_labels, device=self.model.device)
        for i in range(self.prompt_number-1):
            embeddings = keys[i][prefix_labels==i]
            size = embeddings.shape[0]
            self.queue[i][:self.K-size] = self.queue[i][size:].clone()
            self.queue[i][self.K-size:] = embeddings.clone()



            # ptr = int(self.queue_ptr)
        # assert self.K % batch_size == 0  # for simplicity

        # replace the keys at ptr (dequeue and enqueue)
        # self.queue[:, ptr:ptr + batch_size] = keys
        #self.queue = self.queue[batch_size:]
        #self.queue = torch.cat((self.queue, keys), dim=0)
        # ptr = (ptr + batch_size) % self.K  # move pointer

        # self.queue_ptr[0] = ptr


    def mask_id(self,inputs):
        labels = inputs.clone()
        masked_indices = torch.bernoulli(torch.full(labels.shape, self.mlm_probability,device=self.model.device)).bool()
        labels[~masked_indices] = -100
        indices_replaced = torch.bernoulli(torch.full(labels.shape, 0.8,device=self.model.device)).bool() & masked_indices
        inputs[indices_replaced] = self.tokenizer.convert_tokens_to_ids(self.tokenizer.mask_token)
        indices_random = torch.bernoulli(torch.full(labels.shape, 0.5,device=self.model.device)).bool() & masked_indices & ~indices_replaced
        random_words = torch.randint(len(self.tokenizer), labels.shape, dtype=torch.long,device=self.model.device)
        inputs[indices_random] = random_words[indices_random]
        return inputs, labels




    def forward(self, sentence_features: Iterable[Dict[str, Tensor]], labels: list,prefix_labels: list):
        sentence_feature_a, sentence_feature_b, sentence_feature_c = sentence_features

        rep_b = []
        embeddings = []
        loss0 = []
        loss1 = []
        loss2 = []

        #self.model[0].auto_model.set_flag("prefix_tokens", 0)
        #rep_a = self.model(sentence_feature_a)['cls_embedding']
        #self.model[0].auto_model.unset_flag("prefix_tokens1")
        #self.model[0].auto_model.set_flag("prefix_tokens2", True)
        #rep_b = self.model(sentence_feature_a)['cls_embedding']
            #self.model[0].auto_model.unset_flag("prefix_tokens")
        """
        self.model[0].auto_model.set_flag("prefix_tokens", 4)
        rep_a = self.model(sentence_feature_a)['sentence_embedding']
        rep_c = self.model(sentence_feature_a)['sentence_embedding']
        self.model[0].auto_model.unset_flag("prefix_tokens")
        """
        rep_a = []
        rep_c = []
        for i in range(self.prompt_number):
            self.model[0].auto_model.set_flag("prefix_tokens", i)
            embedding = self.model(sentence_feature_b)['sentence_embedding']
            embedding_query1 = self.model(sentence_feature_a)['sentence_embedding']
            embedding_query2 = self.model(sentence_feature_a)['sentence_embedding']
            self.model[0].auto_model.unset_flag("prefix_tokens")
            prompt_label = [[1] if int(j) == i else [0] for j in prefix_labels]
            prompt_label = torch.tensor(prompt_label, dtype=torch.float,
                                            device=self.model.device)
            embeddings.append(embedding)
            rep_b.append(embedding * prompt_label)
            rep_a.append(embedding_query1 * prompt_label)
            rep_c.append(embedding_query2 * prompt_label)

        abs_emb = sum(rep_b)
        rep_a = sum(rep_a)
        rep_c = sum(rep_c)




            # rep_c = self.model(sentence_feature_b)['sentence_embedding']
        labels1 = torch.tensor(range(len(rep_a)),
                                 device=self.model.device)  # Example a[i] should match with b[i]
            # labels2 = torch.tensor(range(len(scores2)), dtype=torch.long, device=scores.device)
        one_hot1 = torch.nn.functional.one_hot(labels1).float()  # 对标签进行one_hot编码
        """
            with torch.no_grad():
                for param_q, param_k in zip(self.model.parameters(), self.model2.parameters()):
                    param_k.data = param_k.data * self.m + param_q.data * (1. - self.m)
        """


        label =  [[] for i in range(len(rep_a))]
        weight =  [[] for i in range(len(rep_a))]
        for i in range(len(labels)):
            for j in range(len(labels)):
                #label[i].append(len(labels[i]&labels[j])/len(labels[i]|labels[j]))
                weight[i].append(len(labels[i]&labels[j])/len(labels[i]|labels[j]))
                if (labels[i] & labels[j]):
                    label[i].append(1)
                else:
                    label[i].append(0)

        label = torch.tensor(label, dtype=torch.float,device=self.model.device)
        weight = torch.tensor(weight, dtype=torch.float,device=self.model.device)


        """
            score = self.similarity_fct(rep_a, rep_c) * self.scale1
            softmax = torch.exp(score) / torch.sum(torch.exp(score), dim=1).reshape(-1, 1)
            logsoftmax = torch.log(softmax)
            loss0 = -torch.sum(label* logsoftmax)
            loss0 = loss0/(torch.sum(label.bool()))
        """

        score_query = self.similarity_fct(rep_a, rep_c) * self.scale2
        #print(score_query)
        softmax_query = torch.exp(score_query) / (torch.exp(score_query)+(torch.sum(torch.exp(score_query)*(1-label)/(torch.sum((1-label),dim=1)/one_hot1.shape[0]), dim=1).reshape(-1, 1)))
        #softmax_query = torch.exp(score_query) / (torch.sum(torch.exp(score_query), dim=1).reshape(-1, 1))
        #softmax_query = torch.sum(softmax_query*label, dim=1).reshape(-1, 1)

        logsoftmax_query = torch.log(softmax_query)
        loss_query= -torch.sum( weight*logsoftmax_query)/torch.sum(weight)




        score_abs = self.similarity_fct(rep_a, abs_emb) * self.scale2
        softmax_abs = torch.exp(score_abs) / (torch.exp(score_abs)+(torch.sum(torch.exp(score_abs)*(1-label)/(torch.sum((1-label),dim=1)/one_hot1.shape[0]), dim=1).reshape(-1, 1)))
        #softmax_abs = torch.exp(score_abs) / (torch.sum(torch.exp(score_abs), dim=1).reshape(-1, 1))
        #softmax_abs = torch.sum(softmax_abs * label, dim=1).reshape(-1, 1)
        logsoftmax_abs = torch.log(softmax_abs)
        loss_abs = -torch.sum(weight* logsoftmax_abs)/torch.sum(weight)



        for i in range(self.prompt_number):
            prompt_label = [1 if int(j) == i else 0 for j in prefix_labels]
            prompt_label = torch.tensor(prompt_label, dtype=torch.float,
                                            device=self.model.device)
            prompt_label = torch.mul(prompt_label.unsqueeze(1), prompt_label.unsqueeze(0))




            scores = []
            scores.append(self.similarity_fct(embeddings[i], embeddings[0]) * self.scale2)
            scores.append(self.similarity_fct(embeddings[i], embeddings[1]) * self.scale2)
            scores.append(self.similarity_fct(embeddings[i], embeddings[2]) * self.scale2)
            scores.append(self.similarity_fct(embeddings[i], embeddings[3]) * self.scale2)

            softmaxs = torch.exp(scores[i]) / (
                    torch.exp(scores[0]) + torch.exp(scores[1]) + torch.exp(scores[2]) + torch.exp(
                scores[3]))
            logsoftmaxs = torch.log(softmaxs)

            loss2.append(-torch.sum(logsoftmaxs * prompt_label * one_hot1))
            """
            scores = []
            scores.append(torch.sum(self.similarity_fct(embeddings[i], embeddings[0]))/(one_hot1.shape[0] *one_hot1.shape[0]))
            scores.append(torch.sum(self.similarity_fct(embeddings[i], embeddings[1]))/(one_hot1.shape[0] *one_hot1.shape[0]))
            scores.append(torch.sum(self.similarity_fct(embeddings[i], embeddings[2]))/(one_hot1.shape[0] *one_hot1.shape[0]))
            scores.append(torch.sum(self.similarity_fct(embeddings[i], embeddings[3]))/(one_hot1.shape[0] *one_hot1.shape[0]))
            
            


            for j in range(self.prompt_number-1):
                if j!=i:
                    loss2.append(self.max(-scores[i]+scores[j]+self.margin))
            """


        #loss0 = sum(loss0) / (torch.sum(label.bool()))

        #loss1 =sum(loss1)/(one_hot1.shape[0])
        #loss1 = 1-(torch.sum(self.similarity_fct(abs_emb,rep_a)*one_hot1)/one_hot1.shape[0])
        loss2 = sum(loss2) / ((self.prompt_number-1)*self.prompt_number)



        return  0.1*loss_query+loss_abs*0.8 +0.1*loss2

    def get_config_dict(self):
        return {'scale': self.scale1, 'similarity_fct': self.similarity_fct.__name__}


    def concat_all_gather(tensor):
        """
        Performs all_gather operation on the provided tensors.
        *** Warning ***: torch.distributed.all_gather has no gradient.
        """
        tensors_gather = [torch.ones_like(tensor)
                        for _ in range(torch.distributed.get_world_size())]
        torch.distributed.all_gather(tensors_gather, tensor, async_op=False)

        output = torch.cat(tensors_gather, dim=0)
        return output

