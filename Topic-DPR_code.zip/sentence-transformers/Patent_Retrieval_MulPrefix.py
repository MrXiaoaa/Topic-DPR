import json
import codecs
import pandas as pd

from torch.utils.data import DataLoader
import math
from sentence_transformers import models, losses
from sentence_transformers import LoggingHandler, SentenceTransformer, util, InputExample
from sentence_transformers.evaluation import EmbeddingSimilarityEvaluator,PromptEmbeddingSimilarityEvaluator,MulInformationRetrievalEvaluator
import logging
from datetime import datetime
import os
import gzip
import csv






import torch
import numpy  as np
import random

def seed_it(seed):
    random.seed(seed) #可以注释掉
    os.environ["PYTHONSEED"] = str(seed)
    np.random.seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed) #这个懂吧
    torch.backends.cudnn.deterministic = True #确定性固定
    torch.backends.cudnn.benchmark = True #False会确定性地选择算法，会降低性能
    torch.backends.cudnn.enabled = True  #增加运行效率，默认就是True
    torch.manual_seed(seed)
seed_it(42)

# 设置随机数种子

# 预处理数据以及训练模型
# ...
# ...





###训练集、验证集、测试集划分 比例0.95：0.01:0.04
import re

re_exp = u"([\’!\"#$%&\'()*+,-./:;<=>?@，。?、…【】《》？“”‘’！["u"\\]^_`{|}~\n])"
# train_samples is a list of InputExample objects where we pass the same sentence twice to texts, i.e. texts=[sent, sent]
train_data = pd.read_csv('../autodl-nas/2021_train.csv', encoding='utf-8')

dev_data = pd.read_csv('../autodl-nas/2021_dev.csv', encoding='utf-8')

test_data = pd.read_csv('../autodl-nas/2021_test.csv', encoding='utf-8')



print('train_data:',len(train_data))
print('dev_data:',len(dev_data))
print('test_data:',len(test_data))
train_data['categories'] =train_data['cpc_section_class_subclasses'].apply(lambda x : str(x)).apply(lambda x : x.split(' '))
dev_data['categories'] =dev_data['cpc_section_class_subclasses'].apply(lambda x : str(x)).apply(lambda x : x.split(' '))
test_data['categories'] =test_data['cpc_section_class_subclasses'].apply(lambda x : str(x)).apply(lambda x : x.split(' '))
#训练样本

train_samples = []
title = train_data['publication_title'].apply(lambda x : str(x)).apply(lambda x : re.sub(re_exp,'',x.rstrip('\n'))).values.tolist()
                            
abstract= train_data['abstract'].apply(lambda x : str(x)).apply(lambda x : re.sub(re_exp,'',x.rstrip('\n'))).values.tolist()
label = train_data['categories'].apply(lambda x : set(x)).values.tolist()
prefix_label = train_data['lda'].values.tolist()



for i,j,h,k in zip(title,abstract,label,prefix_label):
    train_samples.append(InputExample(texts=[i,j],label=h,prefix_label = k))
dev_data['categories_str'] = dev_data['categories'].apply(lambda x: ' '.join(x))
#验证样本
dev_queries ={}
dev_corpus = {}
dev_relevant_docs= {}
dev_query_label = {}
dev_corpus_label = {}


dev_data['categories_str'] = dev_data['categories'].apply(lambda x: ' '.join(x))
dev_queries.update(zip(dev_data.index.values.tolist(),dev_data.publication_title.values.tolist()))
dev_corpus.update(zip(dev_data.index.values.tolist(),dev_data.abstract.values.tolist()))


dev_relevant=[]
for i in range(len(dev_data)):
    relevant_label = '|'.join(dev_data.iloc[i].categories)
    relevant_abstract = dev_data[dev_data['categories_str'].str.contains(relevant_label,na=False)]
    relevant_id = set(relevant_abstract.index.values.tolist())
    dev_relevant.append(relevant_id)
    
dev_relevant_docs.update(zip(dev_data.index.values.tolist(),dev_relevant))



for i,j in zip(dev_data.index.values.tolist(),dev_data.lda.values.tolist()):
    dev_query_label.update({i:j})
    dev_corpus_label.update({i:j})


dev_evaluator = MulInformationRetrievalEvaluator(queries=dev_queries, corpus=dev_corpus,query_label = dev_query_label,corpus_label = dev_corpus_label, corpus_chunk_size=2000,batch_size=24, relevant_docs = dev_relevant_docs)


# Here we define our SentenceTransformer model
model_name = 'output/training_Prefix_IR-bert-base-uncased-16-2023-01-06_17-10-26'


train_batch_size = 16
num_epochs = 1
max_seq_length = 480
word_embedding_model = models.Transformer(model_name, max_seq_length=max_seq_length)
pooling_model = models.Pooling(word_embedding_dimension = word_embedding_model.get_word_embedding_dimension(),pooling_mode_cls_token=True)
model = SentenceTransformer(modules=[word_embedding_model, pooling_model])


# We train our model using the MultipleNegativesRankingLoss
model_save_path = 'output/training_Prefix_IR-{}-{}-{}'.format(model_name, train_batch_size, datetime.now().strftime("%Y-%m-%d_%H-%M-%S"))
train_dataloader = DataLoader(train_samples, shuffle=True, batch_size=train_batch_size, drop_last=True)
#train_loss = losses.MultipleCE(model)

train_loss = losses.MulPrefixContrastiveLoss(model)
#train_loss = losses.MSELoss(model)
warmup_steps = math.ceil(len(train_dataloader) * num_epochs * 0.1)  # 10% of train data for warm-up
#warmup_steps = math.ceil(30000) 
evaluation_steps = math.ceil(len(train_dataloader)*0.05) #Evaluate every 10% of the data#40

logging.info("Training sentences: {}".format(len(train_samples)))
logging.info("Warmup-steps: {}".format(warmup_steps))
logging.info("Performance before training")
dev_evaluator(model)
#Train the model
model.fit(train_objectives=[(train_dataloader, train_loss)],
          evaluator=dev_evaluator,
          epochs=num_epochs,
          evaluation_steps=evaluation_steps,
          warmup_steps=warmup_steps,
          output_path=model_save_path,
          optimizer_params={'lr': 5e-5},
          use_amp=True         #Set to True, if your GPU supports FP16 cores
          )


dev_evaluator(model)









